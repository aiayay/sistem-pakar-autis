<?php  
//membuat koneksi ke database  
//$host = mysqli_connect("localhost","root","","dbautisme");
$host = 'localhost';  
$user = 'root';        
$password = '';        
$database = 'dbautisme';    
      
  $konek_db = mysqli_connect($host, $user, $password, $database);      
?>

