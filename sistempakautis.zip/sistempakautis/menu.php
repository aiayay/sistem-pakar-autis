<?php
// Pastikan session telah dimulai
// Pastikan session telah dimulai
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Pastikan level pengguna telah diset sebelumnya
if (!isset($_SESSION['level'])) {
    // Redirect ke halaman login atau halaman lain jika level pengguna belum diset
    header("Location: index.php");
    exit(); // Pastikan skrip berhenti setelah redirect
}

$level = $_SESSION['level'];
?>

<div class="col-sm-2 sidenav">
        <?php
        $level = $_SESSION['level'];
        if ($level == 'admin') {
        ?>
      <p><a href="beranda.php"><button type="button" class="btn btn-primary btn-block active">BERANDA</button></a></p>
      <p><a href="datauser.php"><button type="button" class="btn btn-primary btn-block">DATA USER</button></a></p>
      <p><a href="datapenyakit.php"><button type="button" class="btn btn-primary btn-block">DATA PENYAKIT</button></a></p>
      <p><a href="gejala.php"><button type="button" class="btn btn-primary btn-block">DATA GEJALA</button></a></p>
      <p><a href="basispengetahuan.php"><button type="button" class="btn btn-primary btn-block">BASIS PENGETAHUAN</button></a></p>
      <p><a href="rekam_medis.php"><button type="button" class="btn btn-primary btn-block">REKAM MEDIK</button></a></p>
      <?php } elseif ($level == 'dokter') { ?>
    <p><a href="beranda.php"><button type="button" class="btn btn-primary btn-block active">BERANDA</button></a></p>
      <p><a href="datauser.php"><button type="button" class="btn btn-primary btn-block">DATA USER</button></a></p>
      <p><a href="datapenyakit.php"><button type="button" class="btn btn-primary btn-block">DATA PENYAKIT</button></a></p>
      <p><a href="gejala.php"><button type="button" class="btn btn-primary btn-block">DATA GEJALA</button></a></p>
      <p><a href="basispengetahuan.php"><button type="button" class="btn btn-primary btn-block">BASIS PENGETAHUAN</button></a></p>
      <p><a href="diagnosa.php"><button type="button" class="btn btn-primary btn-block">KONSULTASI</button></a></p>
      <p><a href="rekam_medis.php"><button type="button" class="btn btn-primary btn-block">REKAM MEDIK</button></a></p>
      <?php } elseif ($level == 'pasien') { ?>
      <p><a href="diagnosa.php"><button type="button" class="btn btn-primary btn-block">KONSULTASI</button></a></p>
      <?php } ?>
      <br><br><br>
      <p><a href="logout.php"><button type="button" class="btn btn-primary btn-block" id="myBtn">LOGOUT</button></a></p>
    </div>