<?php
    include('koneksi.php');

    $nama_dokter = isset($_POST['nama_dokter']) ? $_POST['nama_dokter'] : "Tidak ada nama dokter yang tersedia";


    if(isset($_POST['nama_dokter'])) {
        $nama_dokter = $_POST['nama_dokter'];
    } else {
        $nama_dokter = "Tidak ada nama dokter yang tersedia.";
    }
    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cetak Laporan Gejala</title>
    <style>
        h5 {
            margin: 0;
            padding: 0;
        }
        /* Untuk mengatur ukuran logo */
        #logo {
            width: 100px; /* Sesuaikan dengan ukuran logo Anda */
            height: auto;
            display: inline-block; /* agar elemen logo dan teks berdampingan */
            vertical-align: left; /* agar elemen logo dan teks berada di tengah vertikal */
        }
        #title {
            display: inline-block; /* agar elemen logo dan teks berdampingan */
            vertical-align: middle; /* agar elemen logo dan teks berada di tengah vertikal */
        }
        #footer {
            position: absolute;
            bottom: 0;
            right: 0;
            left: 0;
            text-align: right;
            padding: 10px;
            background-color: #f2f2f2; /* Warna latar belakang footer */
        }
    </style>
</head>
<body>
    <center>
        <img id="logo" src="logo.png" alt="Logo" align="left">
        <h2 id="title" align="center">Rumah Sakit Jiwa Prof. HB. Saanin Padang</h2>
        <h5>Jl. Raya Ulu Gadut  Padang, Kelurahan Limau Manis Selatan, Kecamata Pauh, Sumatera Barat, 25129</h5>
        <h5>Telp : (0751) 72001 / (0751) 71378 | Email : rjshbsaanin@yahoo.co.id</h5>
        <h2>Laporan Data Gejala</h2>
      
    </center>

 
    <table border="1" cellpadding="5" cellspacing="0" style="width:100%">
        <tr>
            <th width="1%">No</th>
            <th>Kode Gejala</th>
            <th>Nama Gejala</th>
        </tr>
        <?php
        $no = 1;
        $sql = mysqli_query($konek_db, "SELECT * FROM tbgejala");
        while ($data = mysqli_fetch_array($sql)) {
        ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $data['id_gejala']; ?></td>
                <td><?php echo $data['nmgejala']; ?></td>
            </tr>
            <?php
    }
    // Check if $data['tgl'] is set before accessing it
    $tanggal = isset($data['tgl']) ? date('d-m-Y', strtotime($data['tgl'])) : date('d-m-Y');
?>
    </table>
    <br><br>
    <br><br>
        <table align="right">
            <tr>
                <td>Padang,</td>
                <td><?php echo $tanggal; ?></td>
            </tr>
            <tr>
                <td colspan="3" style="text-align: center;">Dokter</td>
            </tr>
            <br>
            <tr>
                <td colspan="3" style="text-align: center;"><p><?php echo $nama_dokter; ?></p></td>
            </tr>
        </table>


    <!-- <p align=right><?php
        $tanggal = date("d-m-Y");
        echo "Padang, $tanggal";
        echo "<p align=right> Dokter</p>";
        echo "<p align=right> Dr. Harikha Igha Vinda </p>";
        ?></p> -->
    <div id="footer">
        
    </div>
    <script>
        window.print()
    </script>

</body>
</html>
