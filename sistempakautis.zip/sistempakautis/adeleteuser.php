<?php
include('koneksi.php');
$query="DELETE from user where id_user='".$_GET['id']."'";
mysqli_query($konek_db, $query);
header("location:datauser.php");
?>