<?php

include ('koneksi.php');
session_start();


if(isset($_POST['username'])&& isset ($_POST['password'])){
    $user= $_POST['username'];
    $pass=$_POST['password'];

//include('koneksi.php');

//$error='';

  //  if (mysqli_connect_errno()) {
    //        printf("Connect failed: %s\n", mysqli_connect_error());
      //  exit();
       // }

       $query = mysqli_prepare($konek_db, "SELECT * FROM user WHERE nama=? AND password=?");
       mysqli_stmt_bind_param($query, "ss", $user, $pass); // Mengikat kedua variabel $user dan $pass
       mysqli_stmt_execute($query);
       $result = mysqli_stmt_get_result($query);
       



if(mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
$username=$row['nama'];
$password=$row['password'];
$level=$row['level'];
   
              if($user==$username && $pass ==$password){
               // $_SESSION['username'] = $username;
               $_SESSION['level'] = $level; // Set session level
                header("location:beranda.php");
                exit();
            }else{
                header("location:index.php?pesan=gagal");
                exit();
            }
        }else {
            header("location: index.php?pesan=gagal"); // Redirect ke halaman login dengan pesan gagal
            exit();
        }
    } else {
        // Redirect ke halaman login jika tidak ada data yang dikirim melalui metode POST
        header("location: index.php");
        exit();
    }
    
 ?>