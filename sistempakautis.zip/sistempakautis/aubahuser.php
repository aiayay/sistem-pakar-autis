<?php
include('koneksi.php');
 
if(isset($_SESSION['login_user'])){
header("location: about.php");
exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Pakar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
      </ul>
      <ul class="nav navbar-nav navbar-right">
          
          
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
  <?php include "menu.php"; ?>
    <!-- <div class="col-sm-2 sidenav">
    <p><a href="homeadmin.php"><button type="button" class="btn btn-primary btn-block active">BERANDA</button></a></p>
      <p><a href="datauser.php"><button type="button" class="btn btn-primary btn-block">DATA USER</button></a></p>
      <p><a href="hamadanpenyakit.php"><button type="button" class="btn btn-primary btn-block">DATA PENYAKIT</button></a></p>
      <p><a href="gejala.php"><button type="button" class="btn btn-primary btn-block">DATA GEJALA</button></a></p>
      <p><a href="basispengetahuan.php"><button type="button" class="btn btn-primary btn-block">DATA RULE</button></a></p>
      <p><a href="diagnosa.php"><button type="button" class="btn btn-primary btn-block">KONSULTASI</button></a></p>
      <p><a href="rekam_medis.php"><button type="button" class="btn btn-primary btn-block">REKAM MEDIK</button></a></p>
      <br><br><br><br><br><br><br><br><br><br>
      <p><a href="logout.php"><button type="button" class="btn btn-primary btn-block" id="myBtn">LOGOUT</button></a></p>
    </div> -->
    <div class="col-sm-8 text-left"> 
        
      <h2 class="text-center">EDIT DATA USER</h2>
    <form method="post">
    <div class="form-group">
      			<br><label class="control-label col-sm-2">ID </label>
      		<div class="col-sm-10">
                <?php
                       $tampil = "SELECT * FROM user where id_user='".$_GET['id']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                       echo "<input type='text'  class='form-control' id='id_user' name='id_user' disabled value='".$data['id_user']."'><br>";
                    }
                ?>
     		 </div>
        </div>
        <div class="form-group">
      			<br><label class="control-label col-sm-2">Nama User </label>
      		<div class="col-sm-10">
                <?php
                       $tampil = "SELECT * FROM user where id_user='".$_GET['id']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                       echo "<input type='text'  class='form-control' id='nama' name='nama' value='".$data['nama']."'><br>";
                    }
                ?>
     		 </div>
        </div>
        <div class="form-group">
      			<br><label class="control-label col-sm-2">Password </label>
      		<div class="col-sm-10">
                <?php
                       $tampil = "SELECT * FROM user where id_user='".$_GET['id']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                       echo "<input type='password'  class='form-control' id='password' name='password' value='".$data['password']."' data-error='Isi kolom dengan benar'><br>";
                    }
                ?>
     		 </div>
        </div>
        <div class="form-group">
      			<br><label class="control-label col-sm-2">Level </label>
      		<div class="col-sm-10">
                <?php
                       $tampil = "SELECT * FROM user where id_user='".$_GET['id']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                      echo "<select class='form-control' id='level' name='level' onChange='this.form.submit();' value='".$data['level']."'>
                      <option>---</option>
                      <option value='admin'>Admin</option>
                      <option value='dokter'>Dokter</option>
                      <option value='pasien'>Pasien</option>
                    </select> <br>";
                    }
                ?>
     		 </div>
        </div>
        <div class="form-group">
      			<br><label class="control-label col-sm-2">Alamat </label>
      		<div class="col-sm-10">
                <?php
                       $tampil = "SELECT * FROM user where id_user='".$_GET['id']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                       echo "<input type='text'  class='form-control' id='alamat' name='alamat' value='".$data['alamat']."' data-error='Isi kolom dengan benar'><br>";
                    }
                ?>
     		 </div>
        </div>
        <div class="form-group">
      			<br><label class="control-label col-sm-2">Nomor Telepon </label>
      		<div class="col-sm-10">
                <?php
                       $tampil = "SELECT * FROM user where id_user='".$_GET['id']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                       echo "<input type='text'  class='form-control' id='notlp' name='notlp' value='".$data['notlp']."' data-error='Isi kolom dengan benar'><br>";
                    }
                ?>
     		 </div>
        </div>

   
      <div class="form-group">
      			<br><label class="control-label col-sm-2">Jenis Kelamin </label>
      		<div class="col-sm-10">
                <?php
                       $tampil = "SELECT * FROM user where id_user='".$_GET['id']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                    
                       echo "<select class='form-control' id='jk' name='jk' onChange='this.form.submit();' value='".$data['jk']."'>
                       <option>---</option>
                       <option value='perempuan'>Perempuan</option>
                       <option value='laki'>Laki-laki</option>
                     </select> <br>";
                    }
                ?>
     		 </div>
        </div>
  
        
        
     <button type="submit" name ="submit" class="btn btn-primary">Simpan</button> 
     <br><br>
     <p><a href="datauser.php"><button type="button" class="btn btn-primary">Kembali</button></a></p>
         <?php
                    if(isset($_POST['submit'])){
                      $id = $_GET['id'];
                      $nama = $_POST['nama'];
                      $password = $_POST['password'];
                      $level = $_POST['level'];
                      $alamat = $_POST['alamat'];
                      $jk = $_POST['jk'];
                      $notlp = $_POST['notlp'];
                    
                          
                      $query="UPDATE user SET
                      nama='".$_POST['nama']."',
                      password='".$_POST['password']."', 
                      level='".$_POST['level']."', 
                      alamat='".$_POST['alamat']."', 
                      jk='".$_POST['jk']."',
                      notlp='".$_POST['notlp']."' WHERE id_user='$id'";
                      
                      $result=mysqli_query($konek_db, $query);
                     
                      if($result){
                        echo '<script language="javascript">';
                        echo 'alert("Data Berhasil disimpan")';
                        echo '</script>';
                        echo '<meta http-equiv="refresh" content="0;URL=\'datauser.php\'" />'; // Arahkan ke halaman datauser.php
        exit(); // Pastikan proses berhenti setelah mengarahkan
                     
                     
                       
                        }

                     
                    } 
                ?>
                <br>
                <br>
        </form><br>
    </div>
  </div>
</div>



</body>
</html>
