<?php
include('koneksi.php');
$query="DELETE from tbpenyakit where id_penyakit='".$_GET['id']."'";
mysqli_query($konek_db, $query);
header("location:datapenyakit.php");
?>