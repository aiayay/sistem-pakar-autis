<?php
include('koneksi.php');
 
if(isset($_SESSION['login_user'])){
header("location: about.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Pakar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
      </ul>
      <ul class="nav navbar-nav navbar-right">
          
          
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
  <?php include "menu.php"; ?>
    <!-- <div class="col-sm-2 sidenav">
    <p><a href="homeadmin.php"><button type="button" class="btn btn-primary btn-block active">BERANDA</button></a></p>
      <p><a href="#"><button type="button" class="btn btn-primary btn-block">DATA USER</button></a></p>
      <p><a href="hamadanpenyakit.php"><button type="button" class="btn btn-primary btn-block">DATA PENYAKIT</button></a></p>
      <p><a href="gejala.php"><button type="button" class="btn btn-primary btn-block">DATA GEJALA</button></a></p>
      <p><a href="basispengetahuan.php"><button type="button" class="btn btn-primary btn-block">DATA RULE</button></a></p>
      <p><a href="diagnosa.php"><button type="button" class="btn btn-primary btn-block">KONSULTASI</button></a></p>
      <p><a href="rekam_medis.php"><button type="button" class="btn btn-primary btn-block">REKAM MEDIK</button></a></p>
      <br><br><br><br><br><br><br><br><br><br>
      <p><a href="logout.php"><button type="button" class="btn btn-primary btn-block" id="myBtn">LOGOUT</button></a></p>
    </div> -->
    <div class="col-sm-8 text-left"> 
        
      <h2 class="text-center">EDIT PENYAKIT</h2>
    <form method="post">
      <div class="form-group">
      			<br><label class="control-label col-sm-2">ID </label>
      		<div class="col-sm-10">
                <?php
                       $tampil = "SELECT * FROM tbpenyakit where id_penyakit='".$_GET['id']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                       echo "<input type='text'  class='form-control' id='id_penyakit' name='id_penyakit' disabled value='".$data['id_penyakit']."'><br>";
                    }
                ?>
     		 </div>
        </div>	
        <div class="form-group">
      			<br><label class="control-label col-sm-2">Nama Penyakit </label>
      		<div class="col-sm-10">
                <?php
                       $tampil = "SELECT * FROM tbpenyakit where id_penyakit='".$_GET['id']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                       echo "<input type='text'  class='form-control' id='nmpenyakit' name='nmpenyakit' value='".$data['nmpenyakit']."'><br>";
                    }
                ?>
     		 </div>
        </div>

        <div class="form-group">
      			<br><label class="control-label col-sm-2">Defenisi </label>
      		<div class="col-sm-10">
                <?php
                       $tampil = "SELECT * FROM tbpenyakit where id_penyakit='".$_GET['id']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                      echo "<textarea  rows='8' class='form-control' id='defenisi' name='defenisi' >".$data['defenisi']."</textarea><br>";
                    }
                ?>
     		 </div>
        </div>

        <div class="form-group">
      			<br><label class="control-label col-sm-2">Solusi </label>
      		<div class="col-sm-10">
                <?php
                       $tampil = "SELECT * FROM tbpenyakit where id_penyakit='".$_GET['id']."'";
                       $sql = mysqli_query ($konek_db,$tampil);
                       while($data = mysqli_fetch_array ($sql))
                    {
                      echo "<textarea  rows='8' class='form-control' id='solusi' name='solusi' >".$data['solusi']."</textarea><br>";
                    }
                ?>
     		 </div>
        </div>
      
     <button type="submit" name ="submit" class="btn btn-primary">Simpan</button>
         <?php
                    if(isset($_POST['submit'])){
                      $id = $_GET['id'];
                      $namapenyakit = $_POST['nmpenyakit'];
                      $defenisi = $_POST['defenisi'];
                      $solusi = $_POST['solusi'];
                 
                      $query="UPDATE tbpenyakit SET 
                      nmpenyakit='".$_POST['nmpenyakit']."', 
                      defenisi='".$_POST['defenisi']."', 
                      solusi='".$_POST['solusi']."' WHERE id_penyakit='$id'";
                      $result=mysqli_query($konek_db, $query);
                    
                      if($result){
                        echo '<script language="javascript">';
                        echo 'alert("Data Berhasil disimpan")';
                        echo '</script>';

                        echo '<meta http-equiv="refresh" content="0;URL=\'datapenyakit.php\'" />'; // Arahkan ke halaman datauser.php
        exit(); // Pastikan proses berhenti setelah mengarahkan
                        }
                    }
                ?>
                <br><br>
                <p><a href="datapenyakit.php"><button type="button" class="btn btn-primary">Batal</button></a></p>
        </form><br>
    </div>
  </div>
</div>



</body>
</html>
