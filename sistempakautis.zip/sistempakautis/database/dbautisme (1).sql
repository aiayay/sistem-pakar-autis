-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 31 Jan 2024 pada 14.58
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbautisme`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbgejala`
--

CREATE TABLE `tbgejala` (
  `id_gejala` varchar(4) NOT NULL,
  `nmgejala` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbgejala`
--

INSERT INTO `tbgejala` (`id_gejala`, `nmgejala`) VALUES
('G001', 'Tidak merespon apabila diajak bicara, dipanggil, dan tidak bisa berinteraksi dengan teman sebayanya'),
('G002', 'Sulit melakukan permainan seusia nya yang menggunakan kemampuan imajinatif'),
('G003', 'Kontak mata kurang'),
('G004', 'Kurang bisa menggunakan mainan sesuai fungsinya'),
('G005', 'Tidak bisa bermain pura-pura'),
('G006', 'Tertawa, menangis, dan tersenyum tanpa sebab'),
('G007', 'Keterlambatan dalam perkembangan berbahasa'),
('G008', 'Sering mengoceh bahasa planet'),
('G009', 'Sering meniru pertanyaan orang atau suara yang didengarnya'),
('G010', 'Tata bahasa kacau'),
('G011', 'Sulit diajak berkomunikasi'),
('G012', 'Menarik tangan orang lain bila ingin sesuatu dan komunikasi non-verbal yang sangat kurang'),
('G013', 'Preokupasi acara tertentu ditelevisi seperti cabang olahraga tertentu'),
('G014', 'Rentang perhatian pendek'),
('G015', 'Gangguan pola tidur'),
('G016', 'Gangguan pola makan'),
('G017', 'Gangguan respon rasa nyeri'),
('G018', 'Angresivitas, implusif, temper tantrum tanpa alasan yang jelas'),
('G019', 'Prilaku ritual, terbatas, repetitif dan stereotipik'),
('G020', 'Mempertahankan rutinitas, sulit menyesuaikan diri dengan perubahan'),
('G021', 'Mempertahankan rutinitas, sulit menyesuaikan diri dengan perubahan'),
('G022', 'Preokupasi bagian tertentu dari tubuh, benda'),
('G023', 'Senang benda berputar'),
('G024', 'Senang benda tertentu seperti botol, sedotan, tali plastik, bungkus cemilan dan lain-lain');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbpenyakit`
--

CREATE TABLE `tbpenyakit` (
  `id_penyakit` varchar(4) NOT NULL,
  `nmpenyakit` varchar(100) NOT NULL,
  `defenisi` text NOT NULL,
  `solusi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbpenyakit`
--

INSERT INTO `tbpenyakit` (`id_penyakit`, `nmpenyakit`, `defenisi`, `solusi`) VALUES
('P001', 'Autisme Interaksi Sosial', 'Autisme interaksi sosial merupakan adanya defisit dalam respon timbal-balik sosial emosional, mulai dari pendekatan sosial yang abnormal, kegagalan dalam membangun percakapan dua arah, ketidakmampuan berbagi minat, emosi, atau afek, hingga kegagalan memulai atau merespon suatu interaksi sosial.', 'Melakukan somatoterapi, pengaturan diet, pendekatan edukasi, pemberian vitamin, melakukan konsultasi secara langsung dengan dokter'),
('P002', 'Autisme Komunikasi', 'Autisme komunikasi merupakan adanya defisit dalam perilaku komunikasi non-verbal yang digunakan pada interaksi sosial, mulai dari integrasi komunikasi verbal dan non-verbal yang buruk, abnormalitas dalam kontak mata dan bahasa tubuh, atau defisit dalam memahami dan menggunakan gestur, hingga kurangnya ekspresi wajah dan komunikasi non-verbal secara keseluruhan.', 'Melakukan somatoterapi, pengaturan diet, pendekatan edukasi, pemberian vitamin, melakukan konsultasi secara langsung dengan dokter'),
('P003', 'Autisme Perilaku', 'Autisme Perilaku merupakan adanya defisit dalam mengembangkan, memelihara, dan memahami relasi, mulai dari kesulitan menyesuaikan perilaku agar sesuai dengan konteks sosial, kesulitan dalam bermain imajinatif atau menjalin pertemanan, hingga tidak adanya ketertarikan untuk bermain dengan teman sebaya.', 'melakukan terapi perilaku, pengaturan diet, pendekatan\r\nedukasi, pemberian vitamin, dan segera melakukan konsultasi dengan dokter');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbrekammedis`
--

CREATE TABLE `tbrekammedis` (
  `id_rekammedis` int(4) NOT NULL,
  `id_penyakit` varchar(4) NOT NULL,
  `gejala` text NOT NULL,
  `id_user` int(11) NOT NULL,
  `tgl` date DEFAULT NULL,
  `dokter` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbrekammedis`
--

INSERT INTO `tbrekammedis` (`id_rekammedis`, `id_penyakit`, `gejala`, `id_user`, `tgl`, `dokter`) VALUES
(302, 'P001', 'Tidak merespon apabila diajak bicara, dipanggil, dan tidak bisa berinteraksi dengan teman sebayanya, Sulit melakukan permainan seusia nya yang menggunakan kemampuan imajinatif, Kontak mata kurang, Kurang bisa menggunakan mainan sesuai fungsinya, Tidak bisa bermain pura-pura, Tertawa, menangis, dan tersenyum tanpa sebab', 7, '2024-01-31', 'Dr. Igha Harikha Vinda'),
(303, 'P003', 'Prilaku ritual, terbatas, repetitif dan stereotipik, Mempertahankan rutinitas, sulit menyesuaikan diri dengan perubahan, Mempertahankan rutinitas, sulit menyesuaikan diri dengan perubahan, Preokupasi bagian tertentu dari tubuh, benda, Senang benda berputar, Senang benda tertentu seperti botol, sedotan, tali plastik, bungkus cemilan dan lain-lain', 7, '2024-01-31', 'Dr. Igha Harikha Vinda');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbrule`
--

CREATE TABLE `tbrule` (
  `di_rule` int(11) NOT NULL,
  `id_gejala` varchar(4) NOT NULL,
  `id_penyakit` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbrule`
--

INSERT INTO `tbrule` (`di_rule`, `id_gejala`, `id_penyakit`) VALUES
(109, 'G001', 'P001'),
(110, 'G002', 'P001'),
(111, 'G003', 'P001'),
(112, 'G004', 'P001'),
(113, 'G005', 'P001'),
(114, 'G006', 'P001'),
(117, 'G007', 'P002'),
(118, 'G008', 'P002'),
(119, 'G009', 'P002'),
(120, 'G010', 'P002'),
(121, 'G011', 'P002'),
(122, 'G012', 'P002'),
(123, 'G013', 'P003'),
(124, 'G014', 'P003'),
(125, 'G015', 'P003'),
(126, 'G016', 'P003'),
(127, 'G017', 'P003'),
(128, 'G018', 'P003'),
(129, 'G019', 'P003'),
(130, 'G020', 'P003'),
(131, 'G021', 'P003'),
(132, 'G022', 'P003'),
(133, 'G023', 'P003'),
(134, 'G024', 'P003');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jk` varchar(100) NOT NULL,
  `notlp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama`, `password`, `level`, `alamat`, `jk`, `notlp`) VALUES
(2, 'admin1', 'admin', 'admin', 'jl. lubug begalung nan xx', 'laki', '2147483647'),
(3, 'Dokter Aini', 'dokter', 'dokter', 'jl. lubug begalung nan xx', 'perempuan', '2147483647'),
(7, 'aini', 'aini', 'pasien', 'jl. lubug begalung nan xx', 'perempuan', '+6285200000000'),
(15, 'Dr. Harikha Igha Vinda', 'dokter', 'dokter', 'Jl. Ulu Gadut, Padang', 'perempuan', '0855555555'),
(16, 'Dokter', 'dokter', 'dokter', 'jl. lubug begalung nan xx', 'perempuan', '+6285200000000'),
(19, 'Dr. Igha Harikha Vinda', 'dokter', 'dokter', 'jl. lubug begalung nan xx', 'perempuan', '+6285200000000');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbgejala`
--
ALTER TABLE `tbgejala`
  ADD PRIMARY KEY (`id_gejala`);

--
-- Indeks untuk tabel `tbpenyakit`
--
ALTER TABLE `tbpenyakit`
  ADD PRIMARY KEY (`id_penyakit`);

--
-- Indeks untuk tabel `tbrekammedis`
--
ALTER TABLE `tbrekammedis`
  ADD PRIMARY KEY (`id_rekammedis`);

--
-- Indeks untuk tabel `tbrule`
--
ALTER TABLE `tbrule`
  ADD PRIMARY KEY (`di_rule`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbrekammedis`
--
ALTER TABLE `tbrekammedis`
  MODIFY `id_rekammedis` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=304;

--
-- AUTO_INCREMENT untuk tabel `tbrule`
--
ALTER TABLE `tbrule`
  MODIFY `di_rule` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
