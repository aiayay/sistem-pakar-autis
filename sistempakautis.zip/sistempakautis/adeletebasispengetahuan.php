<?php
// Check if the delete button is clicked and an ID is provided
if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Include your database connection file
    include "koneksi.php";

    // Prevent SQL Injection by sanitizing the ID
    $id = mysqli_real_escape_string($konek_db, $_GET['id']);

    // Query to delete the rule based on ID
    $query = "DELETE FROM tbrule WHERE id_penyakit = '$id'";

    // Perform the delete operation
    if(mysqli_query($konek_db, $query)) {
        echo "Data berhasil dihapus.";
        echo '<meta http-equiv="refresh" content="0;URL=\'basispengetahuan.php\'" />'; // Arahkan ke halaman datauser.php
        exit(); // Pastikan proses berhenti setelah mengarahkan
    } else {
        echo "Gagal menghapus data. Error: " . mysqli_error($konek_db);
    }

    // Close the database connection
    mysqli_close($konek_db);
}
?>
