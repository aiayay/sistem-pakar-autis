<?php
    include('koneksi.php');
    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cetak Laporan Konsultasi</title>
    <style>
        h5 {
            margin: 0;
            padding: 0;
        }
        /* Untuk mengatur ukuran logo */
        #logo {
            width: 100px; /* Sesuaikan dengan ukuran logo Anda */
            height: auto;
            display: inline-block; /* agar elemen logo dan teks berdampingan */
            vertical-align: left; /* agar elemen logo dan teks berada di tengah vertikal */
        }
        #title {
            display: inline-block; /* agar elemen logo dan teks berdampingan */
            vertical-align: middle; /* agar elemen logo dan teks berada di tengah vertikal */
        }
        #footer {
            position: absolute;
            bottom: 0;
            right: 0;
            left: 0;
            text-align: right;
            padding: 10px;
            background-color: #f2f2f2; /* Warna latar belakang footer */
        }
    </style>
</head>
<body>
    <center>
        <img id="logo" src="logo.png" alt="Logo" align="left">
        <h2 id="title" align="center">Rumah Sakit Jiwa Prof. HB. Saanin Padang</h2>
        <h5>Jl. Raya Ulu Gadut  Padang, Kelurahan Limau Manis Selatan, Kecamata Pauh, Sumatera Barat, 25129</h5>
        <h5>Telp : (0751) 72001 / (0751) 71378 | Email : rjshbsaanin@yahoo.co.id</h5>
        <h2>Laporan Konsultasi Pasien</h2>
    </center>
        <?php
          $no = 1;
          $queri = "SELECT * FROM tbrekammedis 
          INNER JOIN tbpenyakit ON tbrekammedis.id_penyakit = tbpenyakit.id_penyakit
          INNER JOIN user ON tbrekammedis.id_user = user.id_user
          ORDER BY tbrekammedis.id_rekammedis DESC
          LIMIT 1" or die('gagal');

  $hasil=mysqli_query ($konek_db,$queri);   
  $no = 1;
  while ($data = mysqli_fetch_array ($hasil)){
        ?>
        <table>
            <tr>
                <td>Nama Pasien</td>
                <td>:</td>
                <td><?php echo $data['nama']; ?></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td><?php echo $data['alamat']; ?></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>:</td>
                <td><?php echo $data['jk']; ?></td>
            </tr>
            <tr>
                <td>Tanggal Konsultasi</td>
                <td>:</td>
                <td><?php echo date('d-m-Y', strtotime($data['tgl'])); ?></td>
            </tr>
        </table>
        <br>
        <table border="1" cellpadding="5" cellspacing="0" style="width:100%">
        <tr>
            <th width="1%">No</th>
            <th>Nama Penyakit</th>
            <th>Gejala Dipilih</th>
        </tr>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $data['nmpenyakit']; ?></td>
                <td><?php echo $data['gejala']; ?></td>
            </tr>
        </table>
        <br>
        <table>
            <tr>
                <td width="20%">Defenisi Penyakit</td>
                <td>:</td>
                <td><?php echo $data['defenisi']; ?></td>
            </tr>
            <tr>
                <td>Solusi Penyakit</td>
                <td>:</td>
                <td><?php echo $data['solusi']; ?></td>
            </tr>
        </table>
        <br><br>
        <table align="right">
            <tr>
                <td>Padang,</td>
                <td><?php echo date('d-m-Y', strtotime($data['tgl'])); ?></td>
            </tr>
            <tr>
                <td colspan="3" style="text-align: center;">Dokter</td>
            </tr>
            <br>
            <tr>
                <td colspan="3" style="text-align: center;"><br><br><?php echo $data['dokter']; ?></td>
            </tr>
        <?php
        }
        ?>
    </table>
    <br><br>
    <!-- <?php
        $tanggal = date("d-m-Y");
        echo "<p align=right> Padang, $tanggal</p>";
        echo "<p align=right> Dokter</p>";
        echo "<p align=right> Dr. Harikha Igha Vinda </p>";
        ?>
    <div id="footer">
     
    </div> -->
    <script>
        window.print()
    </script>

</body>
</html>
