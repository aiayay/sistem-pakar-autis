<?php
include "koneksi.php";
session_start();// Starting Session // Storing Session

$user_check=$_SESSION['level'];
$sql="SELECT * FROM user WHERE nama='$user_check'";
$ses=mysqli_query($konek_db,$sql);
$row =mysqli_fetch_assoc($ses);
$login_session =isset($row['id_user']) ? $row['id_user']: '';

if(!isset($_SESSION)){
    echo"$user_check";
    
}

?>