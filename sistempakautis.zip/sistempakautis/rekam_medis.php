<?php
include('koneksi.php');

if(isset($_SESSION['login_user'])){
    header("location: about.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Pakar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
      </ul>
      <ul class="nav navbar-nav navbar-right">
          
          
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
  <?php include "menu.php"; ?>
    <div class="col-sm-8 text-left"> 
      <h2 class="text-center">DATA REKAM MEDIK PASIEN</h2>

      <p>Pilih Tanggal</p>
      <form method="GET" action="">
          <label for="tanggal_dari">Dari Tanggal:</label>
          <input type="date" id="tanggal_dari" name="tanggal_dari">
          <label for="tanggal_sampai">Sampai Tanggal:</label>
          <input type="date" id="tanggal_sampai" name="tanggal_sampai">
          <input type="submit" value="Filter" name="filter">
      </form>
      <tr>
      <form method="POST" action="cetakrekam.php" target="_blank">
        <div class="form-group">
            <label for="nama_dokter">Nama Dokter:</label>
            <input type="text" class="form-control" required name="nama_dokter" id="nama_dokter">
        </div>
        
        <input type="hidden" name="tanggal_dari" value="<?php echo $_GET['tanggal_dari'] ?? ''; ?>">
        <input type="hidden" name="tanggal_sampai" value="<?php echo $_GET['tanggal_sampai'] ?? ''; ?>">

        <input type="submit" class="btn btn-primary" value="Cetak">
      </form>

      <div class="box-body table-responsive">
          <table id="example1" class="table table-bordered table-striped">
              <thead>
                  <tr>
                      <th>NO</th>
                      <th>TANGGAL</th>
                      <th>NAMA PASIEN</th>
                      <th>NOMOR TELP</th>
                      <th>JENIS KELAMIN</th>
                      <th>ALAMAT</th>
                      <th>NAMA PENYAKIT</th>
                      <th>GEJALA DIPILIH</th>
                      <th>NAMA DOKTER</th>
                      <th>AKSI</th>
                  </tr>
              </thead>
              <tbody>
              <?php
                if(isset($_GET['filter'])) {
                  $_SESSION['tanggal_dari'] = $_GET['tanggal_dari'];
                  $_SESSION['tanggal_sampai'] = $_GET['tanggal_sampai'];
                  $tanggal_dari = $_SESSION['tanggal_dari'];
    $tanggal_sampai = $_SESSION['tanggal_sampai'];
                

                    $queri = "SELECT * FROM tbrekammedis 
                              INNER JOIN tbpenyakit ON tbrekammedis.id_penyakit = tbpenyakit.id_penyakit
                              INNER JOIN user ON tbrekammedis.id_user = user.id_user
                              WHERE tgl BETWEEN '$tanggal_dari' AND '$tanggal_sampai'";
                } else {
                    $queri = "SELECT * FROM tbrekammedis 
                              INNER JOIN tbpenyakit ON tbrekammedis.id_penyakit = tbpenyakit.id_penyakit
                              INNER JOIN user ON tbrekammedis.id_user = user.id_user";
                }

                $hasil = mysqli_query($konek_db, $queri);
                $no = 1;
                while ($data = mysqli_fetch_array($hasil)) {
                    echo "<tr>";
                    echo "<td>".$no++."</td>";
                    echo "<td>".date("d/m/Y", strtotime($data['tgl']))."</td>";
                    echo "<td>".$data['nama']."</td>";
                    echo "<td>".$data['notlp']."</td>";
                    echo "<td>".$data['jk']."</td>";
                    echo "<td>".$data['alamat']."</td>";
                    echo "<td>".$data['nmpenyakit']."</td>";
                    echo "<td>".$data['gejala']."</td>";
                    echo "<td>".$data['dokter']."</td>";
                    echo "<td><a href=\"hapusrekammedis.php?id=".$data[0]."\" onclick='return checkDelete()'><i class='glyphicon glyphicon-trash'></i></a></td>";
                    echo "</tr>";
                }
              ?>
              </tbody>
          </table>
          <br><br><br><br><br>
      </div>
    </div>
  </div>
</div>
    
<script language="JavaScript" type="text/javascript">
function checkDelete(){
    return confirm('Yakin menghapus data ini?');
}
</script>
    
</body>
</html>
