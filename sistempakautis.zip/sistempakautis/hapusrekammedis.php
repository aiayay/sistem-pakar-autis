<?php
include('koneksi.php');
$query="DELETE from tbrekammedis where id_rekammedis='".$_GET['id']."'";
mysqli_query($konek_db, $query);
header("location:rekam_medis.php");
?>