<?php
include('koneksi.php');
 
if(isset($_SESSION['login_user'])){
  header("location: about.php");
  }

//date_default_timezone_set("Asia/Jakarta");

function performForwardChaining($selectedSymptoms, $konek_db)
{
    $selectedDisease = null;

    $query = "SELECT tbrule.id_penyakit, tbpenyakit.nmpenyakit, tbpenyakit.defenisi, tbpenyakit.solusi, COUNT(tbrule.id_gejala) AS total_gejala
        FROM tbrule 
        INNER JOIN tbpenyakit ON tbrule.id_penyakit = tbpenyakit.id_penyakit 
        WHERE tbrule.id_gejala IN (SELECT id_gejala FROM tbgejala WHERE nmgejala IN ('" . implode("','", $selectedSymptoms) . "')) 
        GROUP BY tbrule.id_penyakit 
        ORDER BY total_gejala DESC 
        LIMIT 1";

    $result = mysqli_query($konek_db, $query);

    if ($row = mysqli_fetch_array($result)) {
        $selectedDisease = $row;
    }

    return $selectedDisease;
}

if (isset($_POST['submit'])) {
  
    $gejala = $_POST['gejala'];
    $selectedDisease = performForwardChaining($gejala, $konek_db);
    
    // Simpan ke tbrekammedis
    if (isset($_POST['simpan'])) {
        
        $id_penyakit = $selectedDisease['id_penyakit'];
        $sql = "INSERT INTO tbrekammedis (id_penyakit) VALUES (?)";
        $stmt = $konek_db->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("s", $id_penyakit);
            if ($stmt->execute()) {
                echo '<script language="javascript">';
                echo 'alert("Data Berhasil disimpan")';
                echo '</script>';
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error: " . $konek_db->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Pakar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
      </ul>
      <ul class="nav navbar-nav navbar-right">
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
  <?php include "menu.php"; ?>
    <!-- <div class="col-sm-2 sidenav">
    <p><a href="homeadmin.php"><button type="button" class="btn btn-primary btn-block active">BERANDA</button></a></p>
    <p><a href="datauser.php"><button type="button" class="btn btn-primary btn-block">DATA USER</button></a></p>
      <p><a href="hamadanpenyakit.php"><button type="button" class="btn btn-primary btn-block">DATA PENYAKIT</button></a></p>
      <p><a href="gejala.php"><button type="button" class="btn btn-primary btn-block">DATA GEJALA</button></a></p>
      <p><a href="basispengetahuan.php"><button type="button" class="btn btn-primary btn-block">DATA RULE</button></a></p>
      <p><a href="diagnosa.php"><button type="button" class="btn btn-primary btn-block">KONSULTASI</button></a></p>
      <p><a href="rekam_medis.php"><button type="button" class="btn btn-primary btn-block">REKAM MEDIK</button></a></p>
      <br><br><br><br><br><br><br><br><br><br>
      <p><a href="logout.php"><button type="button" class="btn btn-primary btn-block" id="myBtn">LOGOUT</button></a></p>
    </div> -->
    <div class="col-sm-8 text-left"> 
      <center><h2>DIAGNOSA PENYAKIT</h2></center>
     
       <br> 
    <div class="form-group has-feedback">
    <label class="control-label col-sm-2" for="nama">Tanggal</label>
            
            <input type="date" class="form-control" required name="tgl" readonly data-error="Isi kolom dengan benar" value="<?php echo date('Y-m-d'); ?>">
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
       
          
    </div>
    <label for="sel1">Nama Dokter</label> 
    <form id="form2" name="form2" method="post" action="diagnosa.php">           
    <select class="form-control" name="dokter">
    <option>Pilih Dokter</option>
    <?php 
        // Koneksi ke database (pastikan $konek_db sudah didefinisikan sebelumnya)

        $query_dokter = "SELECT id_user, nama FROM user WHERE level = 'dokter' ORDER BY id_user DESC";
        $result_dokter = mysqli_query($konek_db, $query_dokter);

        while ($row_dokter = mysqli_fetch_assoc($result_dokter)) {
            echo "<option value='".$row_dokter['nama']."'>
                            ".$row_dokter['nama']."</option>";
        }
        
    ?>
    </select>
    
      <br> 
       <br><label class="control-label col-sm-2">PILIH GEJALA :</label>   
       <br><br>
        <form id="form2" name="form2" method="post" action="diagnosa.php">
        <?php 
        $tampil = "SELECT * FROM tbgejala";
        $query = mysqli_query($konek_db, $tampil);
        while($hasil = mysqli_fetch_array($query)){  
            echo "<input type='checkbox' value='".$hasil['nmgejala']."' name='gejala[]' /> ".$hasil['nmgejala']."<br>";
        }
        ?>        
        <br>

        <button type="submit" name ="submit" onclick="return checkDiagnosa()" class="btn btn-primary">CEK PENYAKIT</button><br><br>
            <div class="panel panel-info">
                <div class="panel-heading">HASIL DIAGNOSA</div>
                <div class="panel-body">
            <div class="box-body table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>NO</th>
						   <!-- <th>Id Penyakit</th>
                            <td>" . $selectedDisease['id_penyakit'] . "</td>-->
                            <th>Nama Penyakit</th>
                            <th>Gejala Dipilih</th>
                          <!--  <th>Defenisi</th>
                            <th>Solusi</th>-->
                            
                        </tr>
                        <p><a href="cetakkonsul.php" target="_blank"><button type="button" class="btn btn-primary">cetak</button></a>
                    </thead>

                    <?php
                    if(isset($_POST['submit'])) {
                        if(isset($_POST['dokter'])) {
                            $dokter=$_POST['dokter'];
            
                            // Lakukan sesuatu dengan $dokter
                        } else {
                            // Lakukan sesuatu jika 'dokter' tidak ditemukan dalam $_POST
                            echo "Data dokter tidak tersedia.";
                        }
        
               

                // Lakukan pengecekan apakah gejala dipilih
                        if(isset($_POST['gejala']) && !empty($_POST['gejala'])) {
                            $tgl = date('Y/m/d');
                // Lakukan sesuatu dengan gejala yang dipilih
                            $id_penyakit   = $selectedDisease['id_penyakit'];
                            $gejalaDipilih = $_POST['gejala'];
                // Gabungkan gejala yang dipilih menjadi satu string dengan koma sebagai pemisah
                            $gejala_terpilih_string = implode(", ", $gejalaDipilih);
                            $dokter=$_POST['dokter'];


                //              --batas deklarasi variabel--
                
                            $query_pasien = "SELECT id_user, nama, alamat, jk,notlp FROM user WHERE level = 'pasien' ORDER BY id_user DESC 
                            LIMIT 1" or die('gagal');
                            $result = $konek_db->query($query_pasien);

                            if ($result->num_rows > 0) {

                            while($row = $result->fetch_assoc()) {
                                $id_user = $row["id_user"];
                                echo "
                                <p>Nama Pasien          : " . $row["nama"] . "</p>
                                <p>Nomor Telepon        : " . $row["notlp"] . "</p>
                                <p>Alamat               : " . $row["alamat"] . "</p>
                                <p>Jenis Kelamin        : " . $row["jk"] . "</p>
                                ";
                                // Simpan ke dalam tabel rekam medis
                                // Misalnya, Anda bisa menggunakan foreach untuk menyimpan setiap gejala ke dalam tabel rekam medis
                        
                                // Lakukan penyimpanan ke dalam tabel rekam medis di sini
                                // Misalnya, melakukan INSERT ke dalam tabel rekam medis
                        
                                $query_insert = "INSERT INTO tbrekammedis (id_penyakit, gejala, id_user, tgl, dokter) VALUES ('$id_penyakit', '$gejala_terpilih_string','$id_user','$tgl','$dokter')";
                                if ($konek_db->query($query_insert) === TRUE) {
                                    echo '<script language="javascript">';
                                    echo 'alert("Data Berhasil disimpan")';
                                    echo '</script>';
                                }else {
                                    echo "Error: " . $query_insert . "<br>" . $konek_db->error;
       // }else {
                                    echo "Harap pilih setidaknya satu gejala.";
    }
}

                            }
                        }

                    }
           
                

                                if (isset($selectedDisease)) {
                                    $tgl_dari_database = date('Y-m-d'); // Contoh tanggal dari database

                                    // Ubah format tanggal dari 'YYYY-MM-DD' menjadi 'DD/MM/YYYY'
                                    $tgl_tampilan = date('d/m/Y', strtotime($tgl_dari_database));


                                    $gejalaDipilih = implode(", ", $gejala);
                                    echo "
                                    <p>Tanggal Konsultasi: " . $tgl_tampilan."</p>
                                        <tr>
                                            <td>1</td>
                                           
                                            <td>" . $selectedDisease['nmpenyakit'] . "</td> 
                                            <td>" . $gejalaDipilih . "</td>  
                                        </tr>
                                        </table>
                                    <p>Defenis Penyakit     : ".$selectedDisease['defenisi']."</p>
                                    <p>Solusi Penyakit      : <b>".$selectedDisease['solusi']."</b></p>";


// Menambahkan input hidden untuk menyimpan id_penyakit ke dalam formulir
                                    echo '<input type="hidden" name="id_penyakit" value="' . $selectedDisease['id_penyakit'] . '">';
                                    
                                }
                                ?>      
  </div>
              </div>
            </div>

    
<br><br>

            </div>
                    </div>
                </div>
               
        </form>
                            </form>
             
    </div>
  </div>
</div>
 

<script language="JavaScript" type="text/javascript">
$(document).ready(function(){
    $("#myBtn").click(function(){
        $("#myModal").modal();
    });
});
function checkDiagnosa(){
    return confirm('Apakah sudah benar gejalanya?');
}




</script>

</body>
</html>
