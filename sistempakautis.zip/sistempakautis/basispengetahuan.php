<?php
include "session.php";

// Buat atau periksa sesi login_user
if (!isset($_SESSION['login_user'])) {
  // Jika tidak ada sesi login_user, atur atau inisialisasi sesi tersebut
  $_SESSION['login_user'] = ""; // Sesuaikan dengan inisialisasi sesuai dengan kebutuhan aplikasi Anda
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Pakar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
$(document).ready( function () {
    $('#example1').DataTable();  
} );
</script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
      </ul>
      <ul class="nav navbar-nav navbar-right">
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
  <?php include "menu.php"; ?>
    <!-- <div class="col-sm-2 sidenav">
    <p><a href="homeadmin.php"><button type="button" class="btn btn-primary btn-block active">BERANDA</button></a></p>
      <p><a href="datauser.php"><button type="button" class="btn btn-primary btn-block">DATA USER</button></a></p>
      <p><a href="hamadanpenyakit.php"><button type="button" class="btn btn-primary btn-block">DATA PENYAKIT</button></a></p>
      <p><a href="gejala.php"><button type="button" class="btn btn-primary btn-block">DATA GEJALA</button></a></p>
      <p><a href="basispengetahuan.php"><button type="button" class="btn btn-primary btn-block">DATA RULE</button></a></p>
      <p><a href="diagnosa.php"><button type="button" class="btn btn-primary btn-block">KONSULTASI</button></a></p>
      <p><a href="rekam_medis.php"><button type="button" class="btn btn-primary btn-block">REKAM MEDIK</button></a></p>
      <br><br><br><br><br><br><br><br><br><br>
      <p><a href="logout.php"><button type="button" class="btn btn-primary btn-block" id="myBtn">LOGOUT</button></a></p>
    </div> -->
    <div class="col-sm-8 text-left"> 
        <h2 class="text-center">Data Basis Pengetahuan</h2>
        <form method="POST" action="cetakbasis.php" target="_blank">
        <div class="form-group">
            <label for="nama_dokter">Nama Dokter:</label>
            <input type="text" class="form-control" required name="nama_dokter" id="nama_dokter">
        </div>

        <input type="submit" class="btn btn-primary" value="Cetak">
      </form>
  
<br>
<a href="abasispengetahuan.php"><button type="button" class="btn btn-default">
  <span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
</button></a>
        <br><br>
            <div class="box-body table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>Kode Penyakit</th>
							              <th>Nama Penyakit</th>
                            <th>Nama Gejala</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                      
                      <tr>
                      <?php
                      $queri="SELECT * FROM tbrule
                              INNER JOIN tbpenyakit ON tbrule.id_penyakit = tbpenyakit.id_penyakit
                              INNER JOIN tbgejala ON tbrule.id_gejala = tbgejala.id_gejala";
                      $hasil=mysqli_query ($konek_db,$queri) or die ("eror");   
                      $no = 1;
                          
                      while ($data = mysqli_fetch_array ($hasil)){
                        ?>
                        <td>
                          <?php
                          	 
                            echo "      
                                   <tr>  
                                   <td>".$no++."</td>
                                   <td>".$data['id_penyakit']."</td>  
                                   <td>".$data['nmpenyakit']."</td>  
                                   <td>".$data['nmgejala']."</td>
                                   <td><a href=\"adeletebasispengetahuan.php?id=".$data['nmpenyakit']."\"  onclick='return checkDelete()'>
                                   <i class='glyphicon glyphicon-trash'></i></a></td>
                                        
                                 </tr>"; 
                        ?></td>
                      </tr>
                      <?php
                      }
                      ?>
                    </tbody>
                     <?php
                  //  if(isset($_POST['rule']))
                   // if($_POST['tanaman']!="jenistanaman"){
                              
 		     
			
                   // }
                
 //?>  
</table><br><br><br><br><br>
        </div>
            </div>
  </div>
</div>

<script language="JavaScript" type="text/javascript">
function checkDelete(){
    return confirm('Yakin menghapus data ini?');
}
</script>

</body>
</html>
