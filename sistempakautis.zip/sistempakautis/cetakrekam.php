<?php
    include('koneksi.php');
    session_start();
    $nama_dokter = isset($_POST['nama_dokter']) ? $_POST['nama_dokter'] : "Tidak ada nama dokter yang tersedia";


    if(isset($_POST['nama_dokter'])) {
        $nama_dokter = $_POST['nama_dokter'];
    } else {
        $nama_dokter = "Tidak ada nama dokter yang tersedia.";
    }

$tanggal_dari = isset($_SESSION['tanggal_dari']) ? $_SESSION['tanggal_dari'] : date('Y-m-d');
$tanggal_sampai = isset($_SESSION['tanggal_sampai']) ? $_SESSION['tanggal_sampai'] : date('Y-m-d');

    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cetak Laporan Rekam Medis</title>
    <style>
        h5 {
            margin: 0;
            padding: 0;
        }
        /* Untuk mengatur ukuran logo */
        #logo {
            width: 100px; /* Sesuaikan dengan ukuran logo Anda */
            height: auto;
            display: inline-block; /* agar elemen logo dan teks berdampingan */
            vertical-align: left; /* agar elemen logo dan teks berada di tengah vertikal */
        }
        #title {
            display: inline-block; /* agar elemen logo dan teks berdampingan */
            vertical-align: middle; /* agar elemen logo dan teks berada di tengah vertikal */
        }
        #footer {
            position: absolute;
            bottom: 0;
            right: 0;
            left: 0;
            text-align: right;
            padding: 10px;
            background-color: #f2f2f2; /* Warna latar belakang footer */
        }
    </style>
</head>
<body>
    <center>
        <img id="logo" src="logo.png" alt="Logo" align="left">
        <h2 id="title" align="center">Rumah Sakit Jiwa Prof. HB. Saanin Padang</h2>
        <h5>Jl. Raya Ulu Gadut  Padang, Kelurahan Limau Manis Selatan, Kecamata Pauh, Sumatera Barat, 25129</h5>
        <h5>Telp : (0751) 72001 / (0751) 71378 | Email : rjshbsaanin@yahoo.co.id</h5>
        <h2>Laporan Rekam Medik</h2>
        <h5>PERIODE : <?php echo date('d/m/Y', strtotime($tanggal_dari)); ?> s/d <?php echo date('d/m/Y', strtotime($tanggal_sampai)); ?></h5>
        <?php if (isset($nama_dokter)): ?>
    
<?php endif; ?>



    </center>

   
    <table border="1" cellpadding="5" cellspacing="0" style="width:100%">
        <tr>
            <th width="1%">No</th>
            <th>TANGGAL</th>
            <th>NAMA PASIEN</th>
                            <th>NOMOR TELP</th>
                            <th>JENIS KELAMIN</th>
                            <th>ALAMAT</th>
                            <th>NAMA PENYAKIT</th>
                            <th>GEJALA DIPILIH</th>
                            <th>NAMA DOKTER</th>        
        </tr>
        <?php
$tanggal_dari = isset($_SESSION['tanggal_dari']) ? $_SESSION['tanggal_dari'] : date('Y-m-d');
$tanggal_sampai = isset($_SESSION['tanggal_sampai']) ? $_SESSION['tanggal_sampai'] : date('Y-m-d');

// Query database sesuai dengan rentang tanggal

$no = 1;
$sql = mysqli_query($konek_db, "SELECT * FROM tbrekammedis 
INNER JOIN tbpenyakit ON tbrekammedis.id_penyakit = tbpenyakit.id_penyakit
INNER JOIN user ON tbrekammedis.id_user = user.id_user
WHERE tgl BETWEEN '$tanggal_dari' AND '$tanggal_sampai'");

while ($data = mysqli_fetch_array($sql)) {
?>
            <tr>
            <td><?php echo $no++; ?></td>
                    <td><?php echo date("d/m/Y", strtotime($data['tgl'])); ?></td>
                    <td><?php echo $data['nama']; ?></td>
                    <td><?php echo $data['notlp']; ?></td>
                    <td><?php echo $data['jk']; ?></td>
                    <td><?php echo $data['alamat']; ?></td>
                    <td><?php echo $data['nmpenyakit']; ?></td>
                    <td><?php echo $data['gejala']; ?></td>
                    <td><?php echo $data['dokter']; ?></td>
            </tr>
            </tr>
        <?php
        }
        // Check if $data['tgl'] is set before accessing it
    $tanggal = isset($data['tgl']) ? date('d-m-Y', strtotime($data['tgl'])) : date('d-m-Y');
        ?>
    </table>
    <br><br>
    <br><br>
        <table align="right">
            <tr>
                <td>Padang,</td>
                <td><?php echo $tanggal; ?></td>
            </tr>
            <tr>
                <td colspan="3" style="text-align: center;">Dokter</td>
            </tr>
            <br>
            <tr>
                <td colspan="3" style="text-align: center;"><p><?php echo $nama_dokter; ?></p></td>
            </tr>
        </table>
    <script>
        window.print()
    </script>

</body>
</html>
