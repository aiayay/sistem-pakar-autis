<?php
include "session.php";
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sistem Pakar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
      </ul>
      <ul class="nav navbar-nav navbar-right">
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
  <?php include "menu.php"; ?>
    <!-- <div class="col-sm-2 sidenav">
    <p><a href="homeadmin.php"><button type="button" class="btn btn-primary btn-block active">BERANDA</button></a></p>
      <p><a href="datauser.php"><button type="button" class="btn btn-primary btn-block">DATA USER</button></a></p>
      <p><a href="hamadanpenyakit.php"><button type="button" class="btn btn-primary btn-block">DATA PENYAKIT</button></a></p>
      <p><a href="gejala.php"><button type="button" class="btn btn-primary btn-block">DATA GEJALA</button></a></p>
      <p><a href="basispengetahuan.php"><button type="button" class="btn btn-primary btn-block">DATA RULE</button></a></p>
      <p><a href="diagnosa.php"><button type="button" class="btn btn-primary btn-block">REKAM MEDIK</button></a></p>
      <br><br><br><br><br><br><br><br><br><br>
      <p><a href="logout.php"><button type="button" class="btn btn-primary btn-block" id="myBtn">LOGOUT</button></a></p>
    </div> -->
    <div class="col-sm-8 text-left"> 
        <h2 class="text-center">TAMBAH DATA RULE</h2>
        <form id="form1" name="form1" method="post" action="abasispengetahuan.php">
		
              </form>
        <br><form id="form1" name="form1" method="post">
				<label for="sel1">Pilih Penyakit</label>            
				<select class="form-control" name="id_penyakit">
				<option>PIlih Penyakit</option>
               <?php 
 			        $tampil="SELECT * FROM tbpenyakit";
			        $query1= mysqli_query($konek_db,$tampil) or die (mysqli_error($konek_db));
                while($hasil=mysqli_fetch_array($query1)){  
					          echo "<option value='".$hasil['id_penyakit']."'>
                                         ".$hasil['id_penyakit']." 
                                         ".$hasil['nmpenyakit']."</option>";
                                        }
					?>
  		  </select>

<br><br>
<form id="form2" name="form2" method="post" action="diagnosa.php">
<label for="sel1">Pilih Gejala</label> 
<select class="form-control" name="id_gejala">
<option>Pilih Gejala</option>
 			<?php 
         
 			$tampil="SELECT * FROM tbgejala";
			$query= mysqli_query($konek_db,$tampil)or die ("eror gaes");
                while($hasil=mysqli_fetch_array($query)){  
                  echo "<option value='".$hasil['id_gejala']."'>
                  ".$hasil['id_gejala']." 
                  ".$hasil['nmgejala']."</option>";
			}
                //  }
					?>
        </select>
        

    <br><button type="submit" name ="submit" class="btn btn-primary">Simpan</button>
     <?php			
        if(isset($_POST['submit'])){
            $id_penyakit= $_POST['id_penyakit'];
            $id_gejala = $_POST['id_gejala'];


            //validasi nama penyakit
            $query2="SELECT * FROM tbrule WHERE id_penyakit = '$id_penyakit' AND id_gejala = '$id_gejala'";
        //    $query2="SELECT tbrule.id_rule, tbrule.id_penyakit, tbpenyakit.nmpenyakit
          //        FROM tbrule INNER JOIN tbpenyakit
            //      ON tbrule.id_penyakit=tbpenyakit.id_penyakit WHERE id_penyakit='$id_penyakit'";
                  $result= $konek_db->query($query2);
                  if($result->num_rows > 0){
                    
                    echo '<script language="javascript">';
                    echo 'alert("Data sudah ada")';
                    echo '</script>';
                    ?>
                <?php
                  }else{
          //  $check_penyakit = "SELECT * FROM tbpenyakit WHERE id_penyakit = '$id_penyakit'";
           // $result_penyakit = $konek_db->query($check_penyakit);



        // Query untuk memeriksa keberadaan id_gejala di tbgejala
    //    $check_gejala = "SELECT * FROM tbgejala WHERE id_gejala = '$id_gejala'";
      //  $result_gejala = $konek_db->query($check_gejala);

        //if ($result_penyakit->num_rows > 0 && $result_gejala->num_rows > 0) {

          //echo '<script language="javascript">';
            //  echo 'alert("Data sudah ada di database")';
              //echo '</script>';} else{

            // Jika id_penyakit dan id_gejala ada, maka lakukan penambahan data ke tbrule
            $sql = "INSERT INTO tbrule VALUES ('','$id_gejala', '$id_penyakit')";

            if ($konek_db->query($sql) === TRUE) {
              echo '<script language="javascript">';
              echo 'alert("Data Berhasil disimpan")';
              echo '</script>';
            } else {
                echo "Error: " . $sql . "<br>" . $konek_db->error;
            }
        } 
 }

    $konek_db->close();
    ?>


    

                <br><br>
        <p><a href="basispengetahuan.php"><button type="button" class="btn btn-primary">Kembali</button></a></p>
        </form>
        <br>
        <br>
        </form>
    </div>
  </div>
</div>



</body>
</html>
